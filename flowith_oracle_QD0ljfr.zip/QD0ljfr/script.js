document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();

    const loadCodeFile = async (filePath, containerId) => {
        const container = document.getElementById(containerId);
        if (!container) {
            console.error(`Container with ID "${containerId}" not found.`);
            return;
        }
        try {
            const response = await fetch(filePath);
            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
            const content = await response.text();
            container.textContent = content;
            hljs.highlightElement(container);
        } catch (error) {
            container.textContent = `Error loading file: ${filePath}`;
            console.error(`Failed to load code file "${filePath}":`, error);
        }
    };
    
    const loadMarkdownFile = async (filePath, containerId) => {
        const container = document.getElementById(containerId);
        if (!container) {
            console.error(`Container with ID "${containerId}" not found.`);
            return;
        }
        try {
            const response = await fetch(filePath);
            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
            const markdown = await response.text();
            container.innerHTML = marked.parse(markdown);
        } catch (error) {
            container.innerHTML = `<p class="text-red-400">Error loading content: ${filePath}</p>`;
            console.error(`Failed to load markdown file "${filePath}":`, error);
        }
    };

    const loadAllContent = () => {
        loadCodeFile('project_files/src/sorter.py', 'sorter-code');
        loadCodeFile('project_files/tests/test_sorter.py', 'test-sorter-code');
        loadMarkdownFile('project_files/test_report.md', 'test-report-content');
        loadMarkdownFile('project_files/README.md', 'readme-content');
        loadCodeFile('project_files/commit_message.txt', 'commit-message-content');
    };

    loadAllContent();
});
