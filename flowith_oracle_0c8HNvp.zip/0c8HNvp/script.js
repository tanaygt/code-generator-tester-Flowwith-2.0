document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();

    const fileTree = document.getElementById('file-tree');
    const fileNameDisplay = document.getElementById('file-name');
    const fileTypeDisplay = document.getElementById('file-type');
    const markdownContent = document.getElementById('markdown-content');
    const codeContentWrapper = document.getElementById('code-content-wrapper');
    const codeContent = document.getElementById('code-content');
    
    let activeFileItem = null;

    const loadFile = async (path, element) => {
        try {
            const response = await fetch(path);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const content = await response.text();
            
            const filename = path.split('/').pop();
            const extension = filename.split('.').pop();
            
            fileNameDisplay.textContent = filename;
            
            markdownContent.classList.add('hidden');
            codeContentWrapper.classList.add('hidden');

            if (path.endsWith('.md')) {
                fileTypeDisplay.textContent = 'Markdown';
                markdownContent.innerHTML = marked.parse(content);
                markdownContent.classList.remove('hidden');
            } else {
                let lang = 'plaintext';
                if(path.endsWith('.py')) { lang = 'python'; fileTypeDisplay.textContent = 'Python'; }
                else if(path.endsWith('.txt')) { lang = 'plaintext'; fileTypeDisplay.textContent = 'Text'; }
                
                codeContent.textContent = content;
                codeContent.className = `language-${lang} p-8`; // reset classes
                
                codeContentWrapper.classList.remove('hidden');
                hljs.highlightElement(codeContent);
            }

            if (activeFileItem) {
                activeFileItem.classList.remove('bg-gray-700', 'text-white');
            }
            activeFileItem = element;
            activeFileItem.classList.add('bg-gray-700', 'text-white');

        } catch (error) {
            console.error("Failed to load file:", error);
            fileNameDisplay.textContent = 'Error';
            fileTypeDisplay.textContent = '';
            markdownContent.classList.remove('hidden');
            codeContentWrapper.classList.add('hidden');
            markdownContent.innerHTML = `<p class="text-red-400">Failed to load file: ${path}</p>`;
        }
    };

    fileTree.addEventListener('click', (e) => {
        const target = e.target.closest('.file-item');
        if (target) {
            e.preventDefault();
            const path = target.dataset.path;
            if (path) {
                loadFile(path, target);
            }
        }
    });

    const defaultFile = document.querySelector('.file-item[data-path="project_files/README.md"]');
    if (defaultFile) {
        loadFile(defaultFile.dataset.path, defaultFile);
    }
});
